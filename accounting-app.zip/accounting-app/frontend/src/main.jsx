import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { AuthProvider } from "./lib/authContext.jsx";
// The library's own stylesheet — re-added now that exact dependency
// versions are pinned (see package.json). It was removed earlier to fix a
// build crash caused by dependency-version drift resolving to an
// incompatible version whose file layout had changed; with an exact pin,
// that risk is gone. Loading it BEFORE index.css matters: it's not just
// colors — the library relies on this stylesheet for the calendar's
// positioning/visibility mechanics too, which our own minimal hand-written
// overrides never replicated. That gap is the actual root cause of the
// calendar-won't-close bug, not anything in our own onChange/ref logic.
// Importing it here, before index.css, means our dark-mode color
// overrides in index.css (same or higher specificity, later in the
// cascade) still win for anything they specifically target.
import "react-multi-date-picker/dist/styles.css";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
